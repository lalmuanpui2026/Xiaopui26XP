package com.xpcard.game

import com.xpcard.model.*

class GameEngine(private val players: List<Player>) {
    private var deck = mutableListOf<Card>()
    private var hands = mutableMapOf<String, MutableList<Card>>()
    private var trumpSuit: Suit? = null
    private var currentTrick = mutableListOf<Pair<Player, Card>>()
    private var dealerIndex = 0
    private var currentPlayerIndex = 0

    init {
        setupDeck()
    }

    private fun setupDeck() {
        deck.clear()
        for (suit in Suit.values()) {
            for (rank in Rank.values()) {
                deck.add(Card(suit, rank))
            }
        }
    }

    fun startNewRound() {
        deck.shuffle()
        hands.clear()
        val cardsPerPlayer = 52 / players.size
        players.forEachIndexed { index, player ->
            hands[player.id] = deck.subList(index * cardsPerPlayer, (index + 1) * cardsPerPlayer).toMutableList()
        }
        trumpSuit = Suit.values().random()
        currentPlayerIndex = (dealerIndex + 1) % players.size
        currentTrick.clear()
    }

    fun playCard(player: Player, card: Card): Boolean {
        if (players[currentPlayerIndex].id != player.id) return false
        val playerHand = hands[player.id] ?: return false
        if (!playerHand.contains(card)) return false

        // Basic trick-taking rule: follow suit if possible
        if (currentTrick.isNotEmpty()) {
            val leadSuit = currentTrick.first().second.suit
            val hasLeadSuit = playerHand.any { it.suit == leadSuit }
            if (hasLeadSuit && card.suit != leadSuit) return false
        }

        playerHand.remove(card)
        currentTrick.add(player to card)
        
        if (currentTrick.size == players.size) {
            resolveTrick()
        } else {
            currentPlayerIndex = (currentPlayerIndex + 1) % players.size
        }
        return true
    }

    private fun resolveTrick() {
        val winner = determineTrickWinner()
        currentPlayerIndex = players.indexOfFirst { it.id == winner.id }
        currentTrick.clear()
        
        // Update XP for winner
        winner.xp += 10
        updateTier(winner)
    }

    private fun determineTrickWinner(): Player {
        val leadSuit = currentTrick.first().second.suit
        var winningPlay = currentTrick.first()

        for (i in 1 until currentTrick.size) {
            val currentPlay = currentTrick[i]
            val currentCard = currentPlay.second
            val winningCard = winningPlay.second

            if (currentCard.suit == trumpSuit) {
                if (winningCard.suit != trumpSuit || currentCard.rank.value > winningCard.rank.value) {
                    winningPlay = currentPlay
                }
            } else if (currentCard.suit == leadSuit && winningCard.suit != trumpSuit) {
                if (currentCard.rank.value > winningCard.rank.value) {
                    winningPlay = currentPlay
                }
            }
        }
        return winningPlay.first
    }

    private fun updateTier(player: Player) {
        player.tier = when {
            player.xp >= 1000 -> "God"
            player.xp >= 500 -> "Gold"
            player.xp >= 200 -> "Silver"
            else -> "Bronze"
        }
    }

    fun getPlayerHand(playerId: String): List<Card> = hands[playerId] ?: emptyList()
    fun getCurrentState() = GameState(players, currentPlayerIndex, dealerIndex, trumpSuit, currentTrick, emptyMap())
}
