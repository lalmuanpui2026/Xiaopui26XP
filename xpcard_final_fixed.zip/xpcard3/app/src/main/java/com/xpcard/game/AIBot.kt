package com.xpcard.game

import com.xpcard.model.*

class AIBot(val player: Player) {
    fun decideMove(hand: List<Card>, trick: List<Pair<Player, Card>>, trump: Suit?): Card {
        if (trick.isEmpty()) {
            // Lead with lowest card
            return hand.minByOrNull { it.rank.value } ?: hand.first()
        }

        val leadSuit = trick.first().second.suit
        val sameSuitCards = hand.filter { it.suit == leadSuit }

        return if (sameSuitCards.isNotEmpty()) {
            // Follow suit - try to win if possible, otherwise play lowest of suit
            val highestInTrick = trick.filter { it.second.suit == leadSuit }.maxByOrNull { it.second.rank.value }?.second
            val winner = sameSuitCards.filter { it.rank.value > (highestInTrick?.rank?.value ?: 0) }.minByOrNull { it.rank.value }
            winner ?: sameSuitCards.minByOrNull { it.rank.value }!!
        } else {
            // Can't follow suit - use trump or play lowest card
            val trumpCards = hand.filter { it.suit == trump }
            if (trumpCards.isNotEmpty()) {
                trumpCards.minByOrNull { it.rank.value }!!
            } else {
                hand.minByOrNull { it.rank.value }!!
            }
        }
    }
}
