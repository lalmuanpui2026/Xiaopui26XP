package com.xpcard.ui

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.xpcard.databinding.ActivityGameBinding
import com.xpcard.model.Player
import java.util.*

class GameActivity : AppCompatActivity() {
    private lateinit var binding: ActivityGameBinding
    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupGame()
        observeViewModel()
    }

    private fun setupGame() {
        val human = Player(UUID.randomUUID().toString(), "You")
        val bot1 = Player("bot1", "AI Bot 1", isBot = true)
        val bot2 = Player("bot2", "AI Bot 2", isBot = true)
        val bot3 = Player("bot3", "AI Bot 3", isBot = true)
        
        viewModel.initGame(listOf(human, bot1, bot2, bot3))
        
        binding.playerHandRecycler.layoutManager = 
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
            
        showProTip()
    }

    private fun showProTip() {
        val tip = com.xpcard.util.GameConstants.PRO_TIPS.random()
        android.widget.Toast.makeText(this, "Pro Tip: $tip", android.widget.Toast.LENGTH_LONG).show()
    }

    private fun sendEmoji(emoji: String) {
        // Logic to show emoji animation on screen
        android.widget.Toast.makeText(this, "You: $emoji", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun observeViewModel() {
        viewModel.gameState.observe(this) { state ->
            // Update UI with state
            updateTrickUI(state)
        }

        viewModel.playerHand.observe(this) { hand ->
            // Update recycler view adapter with cards
        }
    }

    private fun updateTrickUI(state: com.xpcard.model.GameState) {
        // Render cards in the middle of the table
    }
}
