package com.xpcard.ui

import androidx.lifecycle.*
import com.xpcard.game.GameEngine
import com.xpcard.model.*
import kotlinx.coroutines.launch

class GameViewModel : ViewModel() {
    private val _gameState = MutableLiveData<GameState>()
    val gameState: LiveData<GameState> = _gameState

    private val _playerHand = MutableLiveData<List<Card>>()
    val playerHand: LiveData<List<Card>> = _playerHand

    private lateinit var gameEngine: GameEngine

    fun initGame(players: List<Player>) {
        gameEngine = GameEngine(players)
        gameEngine.startNewRound()
        updateState()
    }

    fun playCard(player: Player, card: Card) {
        if (gameEngine.playCard(player, card)) {
            updateState()
        }
    }

    private fun updateState() {
        _gameState.value = gameEngine.getCurrentState()
        val currentPlayerId = gameEngine.getCurrentState().players[0].id // Assuming index 0 is human
        _playerHand.value = gameEngine.getPlayerHand(currentPlayerId)
    }
}
