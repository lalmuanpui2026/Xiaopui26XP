package com.xpcard.util

object GameConstants {
    val PRO_TIPS = listOf(
        "Always try to follow the lead suit to avoid penalties.",
        "Save your high trump cards for the final tricks.",
        "Watch which cards other players have played to guess their remaining hand.",
        "Winning a trick earns you 10 XP points!",
        "The Round Starter (RS) changes every round, so adapt your strategy."
    )

    val EMOJIS = listOf("😊", "😎", "🤔", "😢", "🔥", "👍", "👎")
}
