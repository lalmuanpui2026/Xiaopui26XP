package com.xpcard.data

import android.content.Context
import androidx.room.*
import com.xpcard.model.Player

@Dao
interface PlayerDao {
    @Query("SELECT * FROM players ORDER BY xp DESC")
    suspend fun getLeaderboard(): List<Player>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: Player)

    @Query("SELECT * FROM players WHERE id = :playerId")
    suspend fun getPlayerById(playerId: String): Player?

    @Update
    suspend fun updatePlayer(player: Player)
}

@Database(entities = [Player::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun playerDao(): PlayerDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "xp_card_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
