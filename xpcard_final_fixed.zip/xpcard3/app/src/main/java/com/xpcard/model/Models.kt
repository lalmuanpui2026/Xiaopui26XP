package com.xpcard.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Suit {
    SPADES, HEARTS, DIAMONDS, CLUBS
}

enum class Rank(val value: Int) {
    TWO(2), THREE(3), FOUR(4), FIVE(5), SIX(6), SEVEN(7), EIGHT(8), NINE(9), TEN(10),
    JACK(11), QUEEN(12), KING(13), ACE(14)
}

data class Card(
    val suit: Suit,
    val rank: Rank,
    val id: Int = (suit.ordinal * 13) + rank.value
)

@Entity(tableName = "players")
data class Player(
    @PrimaryKey val id: String,
    val name: String,
    var xp: Int = 0,
    var avatar: String = "default",
    val isBot: Boolean = false,
    var tier: String = "Bronze"
)

data class GameState(
    val players: List<Player>,
    val currentPlayerIndex: Int,
    val dealerIndex: Int,
    val trumpSuit: Suit?,
    val currentTrick: List<Pair<Player, Card>>,
    val scores: Map<String, Int>
)
