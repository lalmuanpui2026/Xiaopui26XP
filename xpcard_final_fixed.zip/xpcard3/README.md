# XP Card - Android Game

A traditional Myanmar/Mizo trick-taking card game built with Kotlin and MVVM.

## GitHub Features
This project is configured with **GitHub Actions**. 
- Every time you push code to GitHub, it will automatically build the project.
- You can find the installable **APK file** in the "Actions" tab of your GitHub repository under "Artifacts".

## How to use on GitHub
1. Upload this project to your GitHub repository.
2. Click on the **Actions** tab at the top of your GitHub page.
3. You will see a workflow named "Android CI Build".
4. Once it finishes, click on the build run to download the `xp-card-debug-apk`.

## Tech Stack
- **Language**: Kotlin
- **Architecture**: MVVM
- **CI/CD**: GitHub Actions (Auto-build APK)
- **Database**: Room
- **UI**: ViewBinding, RecyclerView, Lottie
